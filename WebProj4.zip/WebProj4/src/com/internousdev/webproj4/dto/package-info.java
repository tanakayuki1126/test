/**
 * 
 */
/**
 * @author User
 *
 */
package com.internousdev.webproj4.dto;