
public class Iphone {
	public static void main(String[] args) {
		SmartPhone2 iphone =new SmartPhone2();
		iphone.play();
		iphone.stop();
		iphone.next();
		iphone.back();
		iphone.call();
		iphone.mail();
		iphone.photo();
		iphone.internet();
	}
}
