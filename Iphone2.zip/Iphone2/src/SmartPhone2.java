
public class SmartPhone2 extends Phone implements Mp3Player,NewFunction{

	}