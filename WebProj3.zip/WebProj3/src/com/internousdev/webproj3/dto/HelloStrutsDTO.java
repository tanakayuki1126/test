package com.internousdev.webproj3.dto;

public class HelloStrutsDTO {
 private String result;

 public String getResult() {
  return result;
 }

 public void setResult(String result) {
  this.result = result;
 }
}
